# -*- coding: utf-8 -*-

{
    "name": "PrimeTech Association Management",
    "summary": "Association Management for Odoo 18 Community",
    "version": "18.0.1.0.0",
    "category": "Services",
    "author": "PrimeTech Services",
    "website": "https://www.primetechafrik.com",
    "license": "LGPL-3",

    "description": """
PrimeTech Association Management

Version de développement (Debug)

Fonctionnalités en cours de développement :
- Gestion des membres
- Cotisations
- Paiements
- Réunions
- Présences
- Dons
- Dépenses
- Tableau de bord
""",

    "depends": [
        "base",
        "mail",
        "contacts",
        "web",
    ],


    "data": [

        # =====================================================
        # SECURITY
        # =====================================================

        "security/association_security.xml",
        "security/ir.model.access.csv",

        # =====================================================
        # DATA
        # =====================================================

        "data/association_sequence.xml",
        "data/member_category_data.xml",
        "data/member_function_data.xml",

        # =====================================================
        # MENUS
        # =====================================================

        "views/menu_views.xml",

        # =====================================================
        # DASHBOARD
        # =====================================================

        "views/dashboard_views.xml",

        # =====================================================
        # MEMBRES
        # =====================================================

        "views/member_views.xml",
        "views/member_card_views.xml",

        # =====================================================
        # COMITÉ
        # =====================================================

        "views/committee_views.xml",

        # =====================================================
        # FINANCES
        # =====================================================

        "views/subscription_views.xml",
        "views/payment_views.xml",
        "views/donation_views.xml",
        "views/income_views.xml",
        "views/expense_views.xml",
        "views/fund_views.xml",

        # =====================================================
        # ACTIVITÉS
        # =====================================================

        "views/meeting_views.xml",
        "views/attendance_views.xml",
        "views/penalty_views.xml",

        # =====================================================
        # CONFIGURATION
        # =====================================================

        "views/configuration_views.xml",
        "views/res_config_settings_views.xml",

        # =====================================================
        # RAPPORTS
        # =====================================================

        "report/member_card_report.xml",
        "report/attendance_report.xml",
        "report/financial_report.xml",
    ],
    "demo": [],

    "images": [
        "static/description/banner.png",
    ],

    "installable": True,
    "application": True,
    "auto_install": False,
}